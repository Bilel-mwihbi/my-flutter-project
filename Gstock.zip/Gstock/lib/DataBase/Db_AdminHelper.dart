import 'dart:io';

import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path_provider/path_provider.dart';


class Db_AdminHelper {
  static final _databaseName = "MyDatabase.db";
  static final _databaseVersion = 1;

  static final tableAdmin = 'admin';

  static final columnId = 'admin_id';
  static final columnAdminName = 'admin_name';
  static final columnEmail = 'email';
  static final columnPassword = 'password';

  /********** Tab Category ******/

  static final tableCategory = 'category';
  static final CategoryId = 'category_id';
  static final CategoryName = 'category_name';

  Db_AdminHelper._privateConstructor();

  static final Db_AdminHelper instance = Db_AdminHelper._privateConstructor();


  Database? _database = null;

  Future<Database> get database async {
    if (_database != null) return _database!;

    _database = await _initDatabase();
    return _database!;
  }


  _initDatabase() async {
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, _databaseName);
    return await openDatabase(path,
        version: _databaseVersion,
        onCreate: _onCreate);
  }


  Future _onCreate(Database db, int version) async {
    await db.execute('''
          CREATE TABLE $tableAdmin (
            $columnId TEXT PRIMARY KEY,
            $columnAdminName TEXT NOT NULL,
            $columnEmail TEXT NOT NULL,
            $columnPassword TEXT NOT NULL
          )
          ''');
    await db.execute('''
          CREATE TABLE $tableCategory (
            $CategoryId TEXT PRIMARY KEY,
            $CategoryName TEXT NOT NULL
          )
          ''');
  }


  Future<int> insertAdmin(Map<String, dynamic> row) async {
    Database db = await instance.database;
    return await db.insert(tableAdmin, row);
  }

  Future<int> insertCategory(Map<String, dynamic> row) async {
    Database db = await instance.database;
    return await db.insert(tableCategory, row);
  }
  Future<List<Map<String, dynamic>>> queryCategory() async {
    Database db = await instance.database;
    return await db.query(tableCategory);
  }

  Future<List<Map<String, dynamic>>> queryAdmin() async {
    Database db = await instance.database;
    return await db.query(tableAdmin);
  }


  Future<List<Map<String, dynamic>>?>  getAdmin(Map<String, dynamic> row) async {
    Database db = await instance.database;
     String id = row[columnId];
    String pwd=row[columnPassword];

    var res = await db.rawQuery("SELECT $columnAdminName  FROM $tableAdmin WHERE "
                                "$columnId ='$id' AND "
                                "$columnPassword ='$pwd' ");
    if (res.length>0){
      return res;
    }
    else
      return null;

  }
}