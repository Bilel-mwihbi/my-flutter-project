import 'package:flutter/material.dart';

import 'package:flutter_project/views/AddCatgory.dart';
import 'package:flutter_project/views/AddComponent.dart';
class MainView extends StatefulWidget {
  const MainView({Key? key}) : super(key: key);

  @override
  _MainViewState createState() => _MainViewState();
}

class _MainViewState extends State<MainView> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        primarySwatch: Colors.lightGreen
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: MyDrawer(),
      appBar: AppBar(title: Text("Home"),),
    );
  }

}

class  MyDrawer extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        children: [
          DrawerHeader(
            decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.black54,
                        Colors.blueAccent,
                      ]
                    )
            ),
              child:Center(
            child: CircleAvatar(
              backgroundImage: AssetImage("assets/images/login.png"),
              radius: 50,
            ),
          )
          ),
          ListTile(
            title: Text("Home",style: TextStyle(fontSize: 20),),
            leading: Icon(Icons.home,color: Colors.blueAccent,),
            trailing: Icon(Icons.arrow_right,color: Colors.grey,),
          ),
          ListTile(
            title: Text("Add new Category",style: TextStyle(fontSize: 20),),
            onTap: (){
              Navigator.push(context,
                  MaterialPageRoute(builder: (_)=>AddCategory()));
            },
            leading: Icon(Icons.add_box_outlined,color: Colors.blueAccent,),
            trailing: Icon(Icons.arrow_right,color: Colors.grey,),
          ),
          ListTile(
            title: Text("Add new Component",style: TextStyle(fontSize: 20),),
            onTap: (){
              Navigator.push(context,
                  MaterialPageRoute(builder: (_)=>AddComponent()));
            },
            leading: Icon(Icons.add_business,color: Colors.blueAccent,),
            trailing: Icon(Icons.arrow_right,color: Colors.grey,),
          ),
          ListTile(
            title: Text("Sign off",style: TextStyle(fontSize: 20),),
            leading: Icon(Icons.logout,color: Colors.blueAccent,),
            trailing: Icon(Icons.arrow_right,color: Colors.grey,),
          )
        ],
      ),
    );
  }

}

